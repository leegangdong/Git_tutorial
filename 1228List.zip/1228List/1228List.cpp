// 1228List.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"
#include "DBLinkedList.h"

int main()
{
	List list;
	int data;
	DBLinkedList List;

	List.ListInit(&list);

	List.LInsert(&list, 1);
	List.LInsert(&list, 2);
	//List.LInsert(&list, 3);
	//List.LInsert(&list, 4);
	//List.LInsert(&list, 5);
	//List.LInsert(&list, 6);
	//List.LInsert(&list, 7);
	//List.LInsert(&list, 8);

	if (List.LFirst(&list, &data))
	{
		cout << data;

		while (List.LNext(&list, &data))
			cout << data;

		while (List.LPrevious(&list, &data))
			cout << data;

		cout << endl << endl;
	}
    return 0;
}

